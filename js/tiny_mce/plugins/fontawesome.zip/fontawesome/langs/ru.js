tinymce.addI18n('ru', {
    'Icons': 'Иконки',
    'Web Application': 'Веб-приложения',
    'File Type': 'Типы файлов',
    'Spinner': 'Вращающиеся',
    'Form Control': 'Элементы форм',
    'Currency': 'Валюты',
    'Text Editor': 'Редактирование',
    'Directional': 'Направление',
    'Video Player': 'Видео-плеер',
    'Brand': 'Бренды',
    'Medical': 'Медицина',
    'Transportation': 'Транспорт',
    'Gender': 'Гендерные иконки',
    'Payment': 'Платежные системы',
    'Chart': 'Диаграммы',
    'Hand': 'Иконки жестов'
});