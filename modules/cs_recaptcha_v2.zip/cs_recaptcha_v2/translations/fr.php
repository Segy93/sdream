<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{cs_recaptcha_v2}prestashop>cs_recaptcha_v2_a0ba38416445d35a0b1a4e04202b792f'] = 'reCaptcha v2';
$_MODULE['<{cs_recaptcha_v2}prestashop>cs_recaptcha_v2_aae25791fbe590b28ace195266b9430e'] = 'Ajouter un reCaptcha v2 à votre formulaire de contact';
$_MODULE['<{cs_recaptcha_v2}prestashop>cs_recaptcha_v2_a3635d4428d8cbcf6dccce8442e81505'] = 'a besoin d\'être configuré';
$_MODULE['<{cs_recaptcha_v2}prestashop>cs_recaptcha_v2_43deb32873981edae3e1b412b595aaa7'] = 'La balise HTML button type=\"submit\" name=\"submitMessage\" est introuvable dans \"contact-form.tpl\"';
$_MODULE['<{cs_recaptcha_v2}prestashop>cs_recaptcha_v2_894d6b2a94ab5d23b44b192286ee97b6'] = 'Le template \"contact-form.tpl\" n\'a pas été trouvé dans votre thème !';
$_MODULE['<{cs_recaptcha_v2}prestashop>cs_recaptcha_v2_15cecc39d0a1bd801d2a60bdca3cbd59'] = 'La balise HTML input type=\"submit\" name=\"submitMessage\" est introuvable dans \"contactform.tpl\"';
$_MODULE['<{cs_recaptcha_v2}prestashop>cs_recaptcha_v2_bd16046f9e4bfea5a03cdff213c7f8ec'] = 'Le template \"contactform.tpl\" n\'a pas été trouvé dans votre thème !';
$_MODULE['<{cs_recaptcha_v2}prestashop>cs_recaptcha_v2_de7e39ae12eb7d5e08c84ff8739ee5fc'] = 'Veuillez remplir la clé publique reCaptcha';
$_MODULE['<{cs_recaptcha_v2}prestashop>cs_recaptcha_v2_30c1139b1b654780ec1ef5c35323806d'] = 'Veuillez remplir la clé privée reCaptcha';
$_MODULE['<{cs_recaptcha_v2}prestashop>cs_recaptcha_v2_c888438d14855d7d96a2724ee9c306bd'] = 'Paramètres mis à jour';
$_MODULE['<{cs_recaptcha_v2}prestashop>cs_recaptcha_v2_424b8e35d4c1fd5fd990dd912625e080'] = 'Configuration de reCaptcha v2';
$_MODULE['<{cs_recaptcha_v2}prestashop>cs_recaptcha_v2_77f682c46c4c98d39cfb703d3606f505'] = 'Pour obtenir vos propres clés publiques et privées, veuillez cliquer sur le lien suivant';
$_MODULE['<{cs_recaptcha_v2}prestashop>cs_recaptcha_v2_059cff59cc5ead2a76d5d033c29a4754'] = 'Clé publique reCaptcha';
$_MODULE['<{cs_recaptcha_v2}prestashop>cs_recaptcha_v2_c25f66f2154ee54e4a57ad5c9897a264'] = 'Clé privée reCaptcha';
$_MODULE['<{cs_recaptcha_v2}prestashop>cs_recaptcha_v2_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{cs_recaptcha_v2}prestashop>infos_449aa157aadff0de16e253bc9e097020'] = 'Contact & Support';
$_MODULE['<{cs_recaptcha_v2}prestashop>infos_a981a0cb361275bf800395d4cc6575ee'] = 'Modules Prestashop';
$_MODULE['<{cs_recaptcha_v2}prestashop>infos_23cee12a1623a6fc6f81fc932392791e'] = 'Création de boutique Prestashop';
$_MODULE['<{cs_recaptcha_v2}prestashop>infos_d88946b678e4c2f251d4e292e8142291'] = 'Référencement SEO';
$_MODULE['<{cs_recaptcha_v2}prestashop>infos_3466266f862c31a7649bce288bdc3132'] = 'Une question ? Contactez-nous';
